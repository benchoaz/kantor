-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: docku_lokal
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bidang`
--

DROP TABLE IF EXISTS `bidang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bidang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_bidang` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bidang`
--

LOCK TABLES `bidang` WRITE;
/*!40000 ALTER TABLE `bidang` DISABLE KEYS */;
INSERT INTO `bidang` VALUES (1,'Sekretariat'),(2,'Pemerintahan'),(3,'Ekonomi & Pembangunan'),(4,'Kesejahteraan Rakyat'),(5,'Trantibum');
/*!40000 ALTER TABLE `bidang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disposisi`
--

DROP TABLE IF EXISTS `disposisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disposisi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `external_id` varchar(100) NOT NULL COMMENT 'ID dari sistem luar (misal SuratQu)',
  `perihal` text NOT NULL,
  `instruksi` text,
  `tgl_disposisi` datetime DEFAULT NULL,
  `source_json` json DEFAULT NULL COMMENT 'Copy original payload for audit',
  `payload_hash` varchar(64) DEFAULT NULL COMMENT 'SHA-256 for integrity check',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disposisi`
--

LOCK TABLES `disposisi` WRITE;
/*!40000 ALTER TABLE `disposisi` DISABLE KEYS */;
INSERT INTO `disposisi` VALUES (1,'TEST_001','Test Integrasi dari Terminal','Testing koneksi API','2026-01-01 08:36:33','{\"perihal\": \"Test Integrasi dari Terminal\", \"instruksi\": \"Testing koneksi API\", \"external_id\": \"TEST_001\"}','5a9900749e9a5722d3e3c7ef5e4e147f4e3a445856c4bc85cd3485448e036493','2026-01-01 08:36:33');
/*!40000 ALTER TABLE `disposisi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disposisi_penerima`
--

DROP TABLE IF EXISTS `disposisi_penerima`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disposisi_penerima` (
  `id` int NOT NULL AUTO_INCREMENT,
  `disposisi_id` int NOT NULL,
  `user_id` int NOT NULL,
  `status` enum('baru','dibaca','dilaksanakan') DEFAULT 'baru',
  `tgl_dibaca` datetime DEFAULT NULL,
  `tgl_dilaksanakan` datetime DEFAULT NULL,
  `kegiatan_id` int DEFAULT NULL COMMENT 'Relasi ke dokumentasi di Docku',
  PRIMARY KEY (`id`),
  KEY `disposisi_id` (`disposisi_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `disposisi_penerima_ibfk_1` FOREIGN KEY (`disposisi_id`) REFERENCES `disposisi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `disposisi_penerima_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disposisi_penerima`
--

LOCK TABLES `disposisi_penerima` WRITE;
/*!40000 ALTER TABLE `disposisi_penerima` DISABLE KEYS */;
INSERT INTO `disposisi_penerima` VALUES (1,1,1,'baru',NULL,NULL,NULL);
/*!40000 ALTER TABLE `disposisi_penerima` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foto_kegiatan`
--

DROP TABLE IF EXISTS `foto_kegiatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foto_kegiatan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kegiatan_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `file` varchar(255) NOT NULL,
  `file_hash` varchar(32) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `kegiatan_id` (`kegiatan_id`),
  CONSTRAINT `foto_kegiatan_ibfk_1` FOREIGN KEY (`kegiatan_id`) REFERENCES `kegiatan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foto_kegiatan`
--

LOCK TABLES `foto_kegiatan` WRITE;
/*!40000 ALTER TABLE `foto_kegiatan` DISABLE KEYS */;
INSERT INTO `foto_kegiatan` VALUES (1,1,NULL,'DOC_20251230155039_6953f4cfd45d2.png',NULL,NULL,NULL,'2025-12-30 15:50:39'),(2,2,NULL,'CAM_20251230160722_6953f8ba5499e.jpg',NULL,NULL,NULL,'2025-12-30 16:07:42');
/*!40000 ALTER TABLE `foto_kegiatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integrasi_config`
--

DROP TABLE IF EXISTS `integrasi_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integrasi_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL COMMENT 'Nama Sistem Luar',
  `inbound_key` varchar(100) NOT NULL COMMENT 'API Key untuk masuk ke Docku',
  `outbound_url` varchar(255) DEFAULT NULL COMMENT 'URL Webhook Sistem Luar',
  `outbound_key` varchar(100) DEFAULT NULL COMMENT 'API Key untuk keluar ke Sistem Luar',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integrasi_config`
--

LOCK TABLES `integrasi_config` WRITE;
/*!40000 ALTER TABLE `integrasi_config` DISABLE KEYS */;
INSERT INTO `integrasi_config` VALUES (1,'SuratQu','dc139db7cf594302d51b2d1ef128a47f010869301e55cf1bd67ad38d2bd7f096',NULL,NULL,1,'2026-01-01 08:35:02'),(2,'Telegram','TG-BOT','','8406161277:AAHjTOg9KOVs9abCij0qpbrT0ksNVk2zq_0',1,'2026-01-01 14:24:07');
/*!40000 ALTER TABLE `integrasi_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kegiatan`
--

DROP TABLE IF EXISTS `kegiatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kegiatan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `bidang_id` int NOT NULL,
  `tipe_kegiatan` varchar(100) DEFAULT 'biasa',
  `kategori` varchar(100) DEFAULT NULL,
  `penanggung_jawab` varchar(100) DEFAULT NULL,
  `deskripsi` text,
  `temuan` text,
  `saran_rekomendasi` text,
  `capaian` int DEFAULT '0',
  `pimpinan_rapat` varchar(100) DEFAULT NULL,
  `notulis` varchar(100) DEFAULT NULL,
  `agenda` text,
  `kesimpulan` text,
  `nama_pelapor` varchar(100) DEFAULT NULL,
  `masalah` text,
  `tindak_lanjut` text,
  `status_pengaduan` enum('proses','selesai','arsip') DEFAULT NULL,
  `created_by` int NOT NULL,
  `join_code` varchar(10) DEFAULT NULL,
  `status_ekinerja` enum('belum','sudah','tidak') DEFAULT 'belum',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `join_code` (`join_code`),
  KEY `bidang_id` (`bidang_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `kegiatan_ibfk_1` FOREIGN KEY (`bidang_id`) REFERENCES `bidang` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kegiatan_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kegiatan`
--

LOCK TABLES `kegiatan` WRITE;
/*!40000 ALTER TABLE `kegiatan` DISABLE KEYS */;
INSERT INTO `kegiatan` VALUES (1,'makan2','2025-12-30','besuk',1,'biasa',NULL,'jamal','mkan2 pesta',NULL,NULL,0,'','','','','','','','proses',1,NULL,'belum','2025-12-30 15:50:39'),(2,'makan2','2025-12-30','besuk',1,'biasa',NULL,'Administrator','ulang taon',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'belum','2025-12-30 16:07:42');
/*!40000 ALTER TABLE `kegiatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laporan_ekinerja`
--

DROP TABLE IF EXISTS `laporan_ekinerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `laporan_ekinerja` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kegiatan_id` int NOT NULL,
  `output_kinerja_id` int NOT NULL,
  `uraian_singkat` text COLLATE utf8mb4_unicode_ci,
  `teks_bkn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','siap') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kegiatan_id` (`kegiatan_id`),
  KEY `output_kinerja_id` (`output_kinerja_id`),
  KEY `idx_status` (`status`),
  KEY `idx_kegiatan` (`kegiatan_id`),
  CONSTRAINT `laporan_ekinerja_ibfk_1` FOREIGN KEY (`kegiatan_id`) REFERENCES `kegiatan` (`id`) ON DELETE CASCADE,
  CONSTRAINT `laporan_ekinerja_ibfk_2` FOREIGN KEY (`output_kinerja_id`) REFERENCES `output_kinerja` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laporan_ekinerja`
--

LOCK TABLES `laporan_ekinerja` WRITE;
/*!40000 ALTER TABLE `laporan_ekinerja` DISABLE KEYS */;
/*!40000 ALTER TABLE `laporan_ekinerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifikasi_logs`
--

DROP TABLE IF EXISTS `notifikasi_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifikasi_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `disposisi_id` int NOT NULL,
  `user_id` int NOT NULL,
  `channel` enum('internal','telegram','whatsapp') NOT NULL,
  `recipient` varchar(100) DEFAULT NULL,
  `status` enum('pending','sent','failed') DEFAULT 'pending',
  `error_msg` text,
  `sent_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `disposisi_id` (`disposisi_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifikasi_logs_ibfk_1` FOREIGN KEY (`disposisi_id`) REFERENCES `disposisi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notifikasi_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifikasi_logs`
--

LOCK TABLES `notifikasi_logs` WRITE;
/*!40000 ALTER TABLE `notifikasi_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifikasi_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `output_kinerja`
--

DROP TABLE IF EXISTS `output_kinerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `output_kinerja` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bidang_id` int DEFAULT NULL,
  `nama_output` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_jabatan` enum('staf','kasi','sekcam','camat') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `dasar_hukum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'PP 30/2019, PermenPANRB 6/2022',
  `created_by` int DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_bidang` (`bidang_id`),
  KEY `idx_level_jabatan` (`level_jabatan`),
  KEY `idx_active` (`is_active`),
  CONSTRAINT `output_kinerja_ibfk_1` FOREIGN KEY (`bidang_id`) REFERENCES `bidang` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `output_kinerja`
--

LOCK TABLES `output_kinerja` WRITE;
/*!40000 ALTER TABLE `output_kinerja` DISABLE KEYS */;
INSERT INTO `output_kinerja` VALUES (9,NULL,'Terlaksananya dokumentasi kegiatan pelayanan masyarakat.','staf',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(10,NULL,'Terlaksananya dokumentasi kegiatan pemerintahan.','staf',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(11,NULL,'Tersusunnya laporan kegiatan pemerintahan.','staf',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(12,NULL,'Terlaksananya koordinasi pelaksanaan kegiatan pemerintahan pada bidang terkait.','kasi',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(13,NULL,'Terkendalinya pelaksanaan kegiatan pemerintahan pada bidang.','kasi',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(14,NULL,'Tersinkronisasinya pelaksanaan kegiatan lintas bidang di lingkungan kecamatan.','sekcam',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(15,NULL,'Terlaksananya fasilitasi dan pengendalian administrasi kegiatan kecamatan.','sekcam',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(16,NULL,'Terlaksananya pembinaan dan pengendalian penyelenggaraan pemerintahan kecamatan.','camat',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(17,NULL,'Ditetapkannya arah kebijakan dalam penyelenggaraan pemerintahan kecamatan.','camat',0,'PP 30/2019, PermenPANRB 6/2022',NULL,NULL,'2025-12-31 08:36:37','2025-12-31 08:39:02'),(18,NULL,'Terlaksananya dokumentasi kegiatan pelayanan masyarakat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi kegiatan pelayanan publik','2025-12-31 08:39:02',NULL),(19,NULL,'Terlaksananya dokumentasi kegiatan pemerintahan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi kegiatan administrasi pemerintahan','2025-12-31 08:39:02',NULL),(20,NULL,'Terlaksananya dokumentasi kegiatan kesejahteraan rakyat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi kegiatan kesra','2025-12-31 08:39:02',NULL),(21,NULL,'Terlaksananya dokumentasi kegiatan ekonomi dan pembangunan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi kegiatan ekbang','2025-12-31 08:39:02',NULL),(22,NULL,'Terlaksananya dokumentasi kegiatan ketertiban dan ketentraman.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi kegiatan trantibum','2025-12-31 08:39:02',NULL),(23,NULL,'Terlaksananya dokumentasi rapat koordinasi kecamatan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi rapat/rakor','2025-12-31 08:39:02',NULL),(24,NULL,'Terlaksananya dokumentasi pengaduan masyarakat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi laporan pengaduan','2025-12-31 08:39:02',NULL),(25,NULL,'Terlaksananya dokumentasi tindak lanjut pengaduan masyarakat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi follow-up pengaduan','2025-12-31 08:39:02',NULL),(26,NULL,'Terlaksananya dokumentasi monitoring kegiatan di bidang terkait.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Monitoring pelaksanaan kegiatan','2025-12-31 08:39:02',NULL),(27,NULL,'Terlaksananya dokumentasi kegiatan pembinaan masyarakat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pembinaan & pemberdayaan masyarakat','2025-12-31 08:39:02',NULL),(28,NULL,'Tersusunnya laporan kegiatan pemerintahan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan kegiatan administrasi','2025-12-31 08:39:02',NULL),(29,NULL,'Tersusunnya laporan kegiatan pelayanan masyarakat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan pelayanan publik','2025-12-31 08:39:02',NULL),(30,NULL,'Tersusunnya laporan kegiatan kesejahteraan rakyat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan kesra','2025-12-31 08:39:02',NULL),(31,NULL,'Tersusunnya laporan kegiatan ekonomi dan pembangunan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan ekbang','2025-12-31 08:39:02',NULL),(32,NULL,'Tersusunnya dokumentasi administrasi kegiatan di bidang terkait.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Administrasi kegiatan bidang','2025-12-31 08:39:02',NULL),(33,NULL,'Tersusunnya surat undangan kegiatan kecamatan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Surat undangan resmi','2025-12-31 08:39:02',NULL),(34,NULL,'Tersusunnya notulen rapat di lingkungan kecamatan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Notulen rapat/rakor','2025-12-31 08:39:02',NULL),(35,NULL,'Tersusunnya laporan monitoring pelaksanaan kegiatan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan hasil monitoring','2025-12-31 08:39:02',NULL),(36,NULL,'Tersusunnya laporan pelayanan administrasi kependudukan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan adminduk','2025-12-31 08:39:02',NULL),(37,NULL,'Tersusunnya laporan pelayanan perizinan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan perizinan','2025-12-31 08:39:02',NULL),(38,NULL,'Terinputnya data kegiatan ke sistem informasi kecamatan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Input data ke sistem','2025-12-31 08:39:02',NULL),(39,NULL,'Terinputnya data pelayanan masyarakat ke sistem.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Input data pelayanan','2025-12-31 08:39:02',NULL),(40,NULL,'Terdokumentasinya data kegiatan pemerintahan di bidang terkait.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dokumentasi data bidang','2025-12-31 08:39:02',NULL),(41,NULL,'Tersusunnya laporan kegiatan pemberdayaan masyarakat.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan pemberdayaan','2025-12-31 08:39:02',NULL),(42,NULL,'Terlaksananya dokumentasi kegiatan sosial kemasyarakatan.','staf',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Kegiatan sosial masyarakat','2025-12-31 08:39:02',NULL),(43,NULL,'Terlaksananya koordinasi pelaksanaan kegiatan pemerintahan pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi kegiatan pemerintahan','2025-12-31 08:39:02',NULL),(44,NULL,'Terlaksananya koordinasi pelaksanaan kegiatan pelayanan masyarakat pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi pelayanan','2025-12-31 08:39:02',NULL),(45,NULL,'Terlaksananya koordinasi pelaksanaan kegiatan kesejahteraan rakyat pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi kesra','2025-12-31 08:39:02',NULL),(46,NULL,'Terlaksananya koordinasi pelaksanaan kegiatan ekonomi dan pembangunan pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi ekbang','2025-12-31 08:39:02',NULL),(47,NULL,'Terlaksananya koordinasi pelaksanaan kegiatan ketertiban dan ketentraman pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi trantibum','2025-12-31 08:39:02',NULL),(48,NULL,'Terlaksananya koordinasi penanganan pengaduan masyarakat pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi pengaduan','2025-12-31 08:39:02',NULL),(49,NULL,'Terkendalinya pelaksanaan kegiatan pemerintahan pada bidang.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian kegiatan','2025-12-31 08:39:02',NULL),(50,NULL,'Terkendalinya pelaksanaan kegiatan pelayanan masyarakat pada bidang.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian pelayanan','2025-12-31 08:39:02',NULL),(51,NULL,'Terkendalinya pelaksanaan kegiatan di bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian bidang','2025-12-31 08:39:02',NULL),(52,NULL,'Terkendalinya pelayanan administrasi pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian administrasi','2025-12-31 08:39:02',NULL),(53,NULL,'Terlaksananya monitoring dan evaluasi kegiatan pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Monev kegiatan bidang','2025-12-31 08:39:02',NULL),(54,NULL,'Terfasilitasinya pelaksanaan kegiatan pemerintahan pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Fasilitasi kegiatan','2025-12-31 08:39:02',NULL),(55,NULL,'Terfasilitasinya pelaksanaan kegiatan pelayanan masyarakat pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Fasilitasi pelayanan','2025-12-31 08:39:02',NULL),(56,NULL,'Terfasilitasinya koordinasi dengan instansi terkait pada bidang.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Fasilitasi koordinasi eksternal','2025-12-31 08:39:02',NULL),(57,NULL,'Terfasilitasinya penyelesaian permasalahan teknis pada bidang.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Problem solving teknis','2025-12-31 08:39:02',NULL),(58,NULL,'Terlaksananya pembinaan teknis kepada staf pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pembinaan staf','2025-12-31 08:39:02',NULL),(59,NULL,'Tersusunnya laporan evaluasi pelaksanaan kegiatan pada bidang.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan evaluasi','2025-12-31 08:39:02',NULL),(60,NULL,'Terlaksananya koordinasi monitoring kegiatan pada bidang terkait.','kasi',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi monitoring','2025-12-31 08:39:02',NULL),(61,NULL,'Tersinkronisasinya pelaksanaan kegiatan lintas bidang di lingkungan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Sinkronisasi lintas bidang','2025-12-31 08:39:02',NULL),(62,NULL,'Tersinkronisasinya administrasi kegiatan di lingkungan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Sinkronisasi administrasi','2025-12-31 08:39:02',NULL),(63,NULL,'Tersinkronisasinya perencanaan dan penganggaran kegiatan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Sinkronisasi perencanaan','2025-12-31 08:39:02',NULL),(64,NULL,'Tersinkronisasinya pelaporan kinerja kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Sinkronisasi pelaporan','2025-12-31 08:39:02',NULL),(65,NULL,'Terlaksananya fasilitasi dan pengendalian administrasi kegiatan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Fasilitasi & pengendalian','2025-12-31 08:39:02',NULL),(66,NULL,'Terfasilitasinya koordinasi lintas bidang di lingkungan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Fasilitasi koordinasi','2025-12-31 08:39:02',NULL),(67,NULL,'Terkendalinya pelaksanaan kegiatan lintas bidang di kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian lintas bidang','2025-12-31 08:39:02',NULL),(68,NULL,'Terlaksananya pengendalian administrasi umum dan kepegawaian kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian umum & kepegawaian','2025-12-31 08:39:02',NULL),(69,NULL,'Terfasilitasinya dukungan administratif kepada pimpinan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Dukungan pimpinan','2025-12-31 08:39:02',NULL),(70,NULL,'Tersusunnya laporan administrasi dan keuangan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan adm & keuangan','2025-12-31 08:39:02',NULL),(71,NULL,'Terlaksananya koordinasi monitoring pelaksanaan kegiatan kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi monitoring','2025-12-31 08:39:02',NULL),(72,NULL,'Terfasilitasinya evaluasi kinerja lintas bidang di kecamatan.','sekcam',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Evaluasi kinerja','2025-12-31 08:39:02',NULL),(73,NULL,'Terlaksananya pembinaan dan pengendalian penyelenggaraan pemerintahan kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pembinaan & pengendalian','2025-12-31 08:39:02',NULL),(74,NULL,'Terlaksananya pembinaan aparatur kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pembinaan ASN','2025-12-31 08:39:02',NULL),(75,NULL,'Terlaksananya pengendalian dan evaluasi kinerja kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pengendalian & evaluasi','2025-12-31 08:39:02',NULL),(76,NULL,'Terlaksananya pembinaan dan pengayoman masyarakat di wilayah kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pembinaan masyarakat','2025-12-31 08:39:02',NULL),(77,NULL,'Ditetapkannya arah kebijakan dalam penyelenggaraan pemerintahan kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Penetapan kebijakan','2025-12-31 08:39:02',NULL),(78,NULL,'Ditetapkannya prioritas program dan kegiatan kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Penetapan prioritas','2025-12-31 08:39:02',NULL),(79,NULL,'Terlaksananya koordinasi strategis dengan instansi terkait.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Koordinasi eksternal','2025-12-31 08:39:02',NULL),(80,NULL,'Terlaksananya pembinaan dan koordinasi kepada desa/kelurahan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Pembinaan desa','2025-12-31 08:39:02',NULL),(81,NULL,'Terlaksananya evaluasi penyelenggaraan pemerintahan kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Evaluasi penyelenggaraan','2025-12-31 08:39:02',NULL),(82,NULL,'Tersusunnya laporan penyelenggaraan pemerintahan kecamatan.','camat',1,'PP 30/2019, PermenPANRB 6/2022',NULL,'Laporan penyelenggaraan','2025-12-31 08:39:02',NULL);
/*!40000 ALTER TABLE `output_kinerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengaturan`
--

DROP TABLE IF EXISTS `pengaturan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pengaturan` (
  `id` int NOT NULL,
  `nama_instansi_1` varchar(100) DEFAULT 'PEMERINTAH KABUPATEN PROBOLINGGO',
  `nama_instansi_2` varchar(100) DEFAULT 'KECAMATAN BESUK',
  `alamat_1` varchar(255) DEFAULT 'Jalan Raya Besuk No. 1, Besuk, Probolinggo',
  `alamat_2` varchar(255) DEFAULT 'Email: kecamatan.besuk@probolinggokab.go.id',
  `nama_camat` varchar(100) DEFAULT 'PUJA KURNIAWAN, S.STP., M.Si',
  `nip_camat` varchar(50) DEFAULT '19800101 200001 1 001',
  `jabatan_ttd` varchar(100) DEFAULT 'Camat Besuk',
  `golongan_ttd` varchar(100) DEFAULT 'Pembina Tingkat I (IV/b)',
  `logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengaturan`
--

LOCK TABLES `pengaturan` WRITE;
/*!40000 ALTER TABLE `pengaturan` DISABLE KEYS */;
INSERT INTO `pengaturan` VALUES (1,'PEMERINTAH KABUPATEN PROBOLINGGO','KECAMATAN BESUK','Jalan Raya Besuk No. 1, Besuk, Probolinggo','Email: kecamatan.besuk@probolinggokab.go.id','Handik Hariyanto, S.Kom., M.Si','197909102002121004','Camat Besuk','Pembina Tingkat I (IV/b)',NULL);
/*!40000 ALTER TABLE `pengaturan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','operator','pimpinan') NOT NULL,
  `telegram_id` varchar(50) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `bidang_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_jabatan` (`jabatan`),
  KEY `idx_users_bidang` (`bidang_id`),
  CONSTRAINT `fk_users_bidang` FOREIGN KEY (`bidang_id`) REFERENCES `bidang` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','admin','$2y$10$ap/tpvLG5K1fn.643sVL/uGdyITB7tYPkxGKR3rwvQIkEeX1X0qfC','admin',NULL,NULL,NULL,NULL,NULL,'2025-12-29 13:21:56'),(2,'operator','operator','$2y$10$ZVktvmu238tuM3COxZDDB.jHhoVgrCUDak4b4eLANGbGjEl4pu7Ja','operator',NULL,NULL,NULL,NULL,NULL,'2025-12-29 14:07:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-01 21:51:05
