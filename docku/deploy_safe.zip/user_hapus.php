<?php
// user_hapus.php
require_once 'config/database.php';
require_once 'includes/auth.php';
require_role(['admin']);

$id = $_GET['id'] ?? 0;

if ($id) {
    // Prevent self-deletion and deleting initial admin
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    if ($user && $user['username'] !== 'admin' && $id != $_SESSION['user_id']) {
        $stmt_del = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt_del->execute([$id]);
        header("Location: users.php?msg=deleted");
        exit;
    }
}

header("Location: users.php?msg=error");
exit;
?>
