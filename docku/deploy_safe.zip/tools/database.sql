-- Database Schema for Docku (Dokumentasi Kecamatan)
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS foto_kegiatan, kegiatan, bidang, users;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'operator', 'pimpinan') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bidang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_bidang VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS kegiatan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(255) NOT NULL,
    tanggal DATE NOT NULL,
    lokasi VARCHAR(255) NOT NULL,
    bidang_id INT NOT NULL,
    tipe_kegiatan ENUM('biasa', 'rapat', 'pengaduan') DEFAULT 'biasa',
    penanggung_jawab VARCHAR(100),
    deskripsi TEXT,
    -- Fields for Rapat
    pimpinan_rapat VARCHAR(100) NULL,
    notulis VARCHAR(100) NULL,
    agenda TEXT NULL,
    kesimpulan TEXT NULL,
    -- Fields for Pengaduan
    nama_pelapor VARCHAR(100) NULL,
    masalah TEXT NULL,
    tindak_lanjut TEXT NULL,
    status_pengaduan ENUM('proses', 'selesai', 'arsip') NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bidang_id) REFERENCES bidang(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS foto_kegiatan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kegiatan_id INT NOT NULL,
    file VARCHAR(255) NOT NULL,
    file_hash VARCHAR(32) NULL,
    caption VARCHAR(255),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id) ON DELETE CASCADE
);

-- Initial Data
INSERT INTO bidang (nama_bidang) VALUES 
('Sekretariat'),
('Pemerintahan'),
('Ekonomi & Pembangunan'),
('Kesejahteraan Rakyat'),
('Trantibum');

-- Default Admin (password: admin123)
-- Note: In production, change this immediately.
INSERT INTO users (nama, username, password, role) VALUES 
('Administrator', 'admin', '$2y$10$DupmBV0CALSOfaPHal4JxehhGslevFqmukD5Dv9Rhn9gffav0nBR6', 'admin');
SET FOREIGN_KEY_CHECKS = 1;
