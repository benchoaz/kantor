<?php
// kegiatan_verifikasi.php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Only Admin and Pimpinan (e.g. Camat) can verify
require_role(['admin', 'pimpinan']);

$id = $_GET['id'] ?? 0;
$action = $_GET['action'] ?? 'verify'; // verify or unverify

if ($id) {
    try {
        if ($action === 'verify') {
            $stmt = $pdo->prepare("UPDATE kegiatan SET is_verified = 1, verified_by = ?, verified_at = NOW() WHERE id = ?");
            $stmt->execute([$_SESSION['user_id'], $id]);
            $msg = "Kegiatan berhasil diverifikasi.";
        } else {
            // Unverify
            $stmt = $pdo->prepare("UPDATE kegiatan SET is_verified = 0, verified_by = NULL, verified_at = NULL WHERE id = ?");
            $stmt->execute([$id]);
            $msg = "Verifikasi dibatalkan.";
        }
        
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit;
    } catch (Exception $e) {
        die("Gagal memproses verifikasi: " . $e->getMessage());
    }
} else {
    header("Location: index.php");
    exit;
}
?>
