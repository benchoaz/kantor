<?php
// users.php
require_once 'config/database.php';
require_once 'includes/auth.php';
require_role(['admin']);

$active_page = 'users';
$page_title = 'Manajemen User';
include 'includes/header.php';

$stmt = $pdo->query("SELECT id, username, nama, role, jabatan, nip, created_at FROM users ORDER BY role, nama");
$users = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4 animate-up">
    <div>
        <h3 class="title-main mb-0">Manajemen Pengguna</h3>
        <p class="text-muted small mb-0">Kelola akses dan privilese personil dalam aplikasi</p>
    </div>
    <a href="user_tambah.php" class="btn btn-modern btn-primary-modern shadow-sm">
        <i class="bi bi-person-plus"></i> <span class="d-none d-md-inline ms-1">Tambah User</span>
    </a>
</div>

<div class="card-modern border-0 animate-up" style="animation-delay: 0.1s;">
    <div class="card-body p-0 p-lg-4">
        <div class="table-responsive">
            <table class="table table-modern align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4">Informasi User</th>
                        <th>Jabatan & NIP</th>
                        <th>Role Akses</th>
                        <th class="d-none d-lg-table-cell">Terdaftar</th>
                        <th class="text-end pe-4">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td class="ps-4" data-label="User">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-2 me-3 d-none d-lg-block">
                                    <i class="bi bi-person-badge"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($u['nama']) ?></div>
                                    <div class="small text-muted"><i class="bi bi-at me-1"></i><?= htmlspecialchars($u['username']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td data-label="Jabatan">
                            <div class="small fw-medium"><?= $u['jabatan'] ? htmlspecialchars($u['jabatan']) : '<em>Staff</em>' ?></div>
                            <div class="extra-small text-muted"><?= $u['nip'] ? htmlspecialchars($u['nip']) : 'NIP: -' ?></div>
                        </td>
                        <td data-label="Role">
                            <?php
                            $role_config = [
                                'admin' => ['bg-danger', 'bi-shield-lock'],
                                'operator' => ['bg-primary', 'bi-person-gear'],
                                'pimpinan' => ['bg-success', 'bi-person-check']
                            ];
                            $cfg = $role_config[$u['role']] ?? ['bg-secondary', 'bi-person'];
                            ?>
                            <span class="badge rounded-pill <?= $cfg[0] ?> bg-opacity-10 <?= str_replace('bg-', 'text-', $cfg[0]) ?> border <?= str_replace('bg-', 'border-', $cfg[0]) ?> border-opacity-25 px-3">
                                <i class="bi <?= $cfg[1] ?> me-1"></i> <?= ucfirst($u['role']) ?>
                            </span>
                        </td>
                        <td class="d-none d-lg-table-cell">
                             <div class="small text-muted"><?= date('d M Y', strtotime($u['created_at'])) ?></div>
                        </td>
                        <td class="text-end pe-4" data-label="Aksi">
                            <div class="btn-group">
                                <a href="user_edit.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-light border rounded-pill px-3">
                                    Edit
                                </a>
                                <?php if ($u['username'] !== 'admin' && $u['id'] != $_SESSION['user_id']): ?>
                                <a href="user_hapus.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-light border rounded-pill px-2 ms-1 text-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
