<?php
/**
 * debug.php - SCRIPT UNTUK MELIHAT ERROR DI CPANEL
 * Upload file ini ke root folder cPanel Anda, lalu akses domain.com/debug.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h3>🔎 Docku Debug System</h3>";

echo "<h4>1. Memeriksa Koneksi Database</h4>";
try {
    if (!file_exists('config/database.php')) {
        echo "<b style='color:red'>❌ File config/database.php tidak ditemukan!</b><br>";
    } else {
        require_once 'config/database.php';
        if (isset($pdo)) {
            echo "<b style='color:green'>✅ Koneksi Database Berhasil.</b><br>";
            
            // Cek Versi MySQL
            $version = $pdo->query('select version()')->fetchColumn();
            echo "Versi MySQL Server: " . $version . "<br>";
        } else {
            echo "<b style='color:red'>❌ Variabel \$pdo tidak ditemukan di config/database.php</b><br>";
        }
    }
} catch (Exception $e) {
    echo "<b style='color:red'>❌ Error Database: " . $e->getMessage() . "</b><br>";
}

echo "<h4>2. Memeriksa file pendukung</h4>";
$files = ['includes/auth.php', 'includes/header.php', 'includes/helpers.php', 'includes/notification_helper.php'];
foreach ($files as $f) {
    if (file_exists($f)) {
        echo "✅ File $f: <span style='color:green'>Ada</span><br>";
    } else {
        echo "❌ File $f: <b style='color:red'>HILANG</b><br>";
    }
}

echo "<h4>3. Mengetes Index (Tanpa Redirect)</h4>";
try {
    // Kita coba include file utama secara parsial untuk memicu error jika ada syntax error
    include 'includes/helpers.php';
    echo "✅ Helper loaded.<br>";
    include 'includes/notification_helper.php';
    echo "✅ Notification helper loaded.<br>";
    echo "<br>Jika sampai sini tidak ada error merah, berarti masalah kemungkinan ada di file index.php atau header.php yang melakukan redirect loop.";
} catch (Error $e) {
    echo "<b style='color:red'>❌ Fatal Error: " . $e->getMessage() . "</b> di " . $e->getFile() . " baris " . $e->getLine();
}

echo "<hr><p>Jika halaman ini kosong putih, kemungkinan ada Syntax Error fatal. Periksa file <b>error_log</b> di File Manager cPanel Bapak.</p>";
