<?php
// includes/integration_helper.php

/**
 * Trigger Outbound Webhook when disposition is executed
 */
function triggerOutboundWebhook($pdo, $disposisiId) {
    // 1. Get Disposisi External Info
    $stmt = $pdo->prepare("SELECT d.external_id, ic.outbound_url, ic.outbound_key, ic.label 
                           FROM disposisi d 
                           JOIN integrasi_config ic ON 1=1 
                           WHERE ic.is_active = 1 AND ic.outbound_url IS NOT NULL AND ic.outbound_url != ''
                           LIMIT 1");
    
    $stmt->execute();
    
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $url = $row['outbound_url'];
        $key = $row['outbound_key'];
        
        $payload = json_encode([
            'external_id' => $row['external_id'],
            'status' => 'dilaksanakan',
            'updated_at' => date('Y-m-d H:i:s'),
            'notes' => 'Tindak lanjut telah didokumentasikan di Docku.'
        ]);
        
        // Curl Request
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-API-KEY: ' . $key
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Fast timeout
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        // Log the attempt
        // We can reuse notifikasi_logs or create integration_logs
        // For simplicity, just log to file
        file_put_contents(__DIR__ . '/../logs/integration.log', 
            date('Y-m-d H:i:s') . " [OUTBOUND] To: $url | ID: {$row['external_id']} | Code: $httpCode | Resp: $response\n", 
            FILE_APPEND);
            
        return ($httpCode >= 200 && $httpCode < 300);
    }
    
    return false;
}
?>
