<?php
// includes/auth.php
session_start();

/**
 * Cek apakah user sudah login
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Redirect ke login jika belum login
 */
function require_login() {
    if (!is_logged_in()) {
        // Detect script location and build correct path to login.php
        $script_name = $_SERVER['SCRIPT_NAME'];
        $depth = substr_count(dirname($script_name), '/');
        
        // Build relative path back to root (where login.php is)
        $path_to_root = str_repeat('../', $depth);
        
        header("Location: {$path_to_root}login.php");
        exit;
    }
}

/**
 * Cek role user
 */
function has_role($roles) {
    if (!is_logged_in()) return false;
    
    if (is_array($roles)) {
        return in_array($_SESSION['role'], $roles);
    }
    
    return $_SESSION['role'] === $roles;
}

/**
 * Require specific role
 */
function require_role($roles) {
    require_login();
    if (!has_role($roles)) {
        echo "Akses Ditolak: Anda tidak memiliki izin untuk halaman ini.";
        exit;
    }
}
?>
