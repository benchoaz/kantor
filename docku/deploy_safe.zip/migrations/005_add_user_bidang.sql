-- Migration 005: Add Bidang Assignment to Users
-- Assigns users to specific bidang for data filtering and access control

SET FOREIGN_KEY_CHECKS = 0;

-- Add bidang_id to users table
ALTER TABLE users 
ADD COLUMN bidang_id INT NULL AFTER nip,
ADD CONSTRAINT fk_users_bidang FOREIGN KEY (bidang_id) REFERENCES bidang(id) ON DELETE SET NULL;

-- Add index for faster filtering
CREATE INDEX idx_users_bidang ON users(bidang_id);

SET FOREIGN_KEY_CHECKS = 1;

-- Notes:
-- bidang_id: Assigned bidang/department for the user
-- NULL = No specific bidang (Admin, Camat, Sekcam - full access)
-- NOT NULL = Specific bidang (Kasi, Kasubbag, Staf - limited to their bidang)
--
-- Access Control Logic:
-- - Admin (role=admin): See all bidang (bidang_id can be NULL)
-- - Pimpinan (Camat/Sekcam): See all bidang (bidang_id can be NULL)
-- - Kasi/Kasubbag/Staf: Only see their assigned bidang (bidang_id NOT NULL)
