-- Migration: Add file_hash column to foto_kegiatan
-- Run this in phpMyAdmin on cPanel if your database is missing the column

ALTER TABLE `foto_kegiatan` 
ADD COLUMN `file_hash` VARCHAR(32) NULL AFTER `file`;

-- Add index for performance
ALTER TABLE `foto_kegiatan` 
ADD INDEX `idx_file_hash` (`file_hash`);
