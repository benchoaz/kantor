-- Migration 008: Add Integration & Notification Module Tables
SET FOREIGN_KEY_CHECKS = 0;

-- Tabel Disposisi (Master Data dari Sistem Luar)
CREATE TABLE IF NOT EXISTS `disposisi` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `external_id` VARCHAR(100) NOT NULL COMMENT 'ID dari sistem luar (misal SuratQu)',
  `perihal` TEXT NOT NULL,
  `instruksi` TEXT,
  `tgl_disposisi` DATETIME,
  `source_json` JSON COMMENT 'Copy original payload for audit',
  `payload_hash` VARCHAR(64) COMMENT 'SHA-256 for integrity check',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Mapping Penerima Disposisi (Multi-User)
CREATE TABLE IF NOT EXISTS `disposisi_penerima` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `disposisi_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `status` ENUM('baru', 'dibaca', 'dilaksanakan') DEFAULT 'baru',
  `tgl_dibaca` DATETIME NULL,
  `tgl_dilaksanakan` DATETIME NULL,
  `kegiatan_id` INT DEFAULT NULL COMMENT 'Relasi ke dokumentasi di Docku',
  FOREIGN KEY (disposisi_id) REFERENCES disposisi(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Konfigurasi Integrasi (API Keys & Endpoints)
CREATE TABLE IF NOT EXISTS `integrasi_config` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `label` VARCHAR(50) NOT NULL COMMENT 'Nama Sistem Luar',
  `inbound_key` VARCHAR(100) NOT NULL COMMENT 'API Key untuk masuk ke Docku',
  `outbound_url` VARCHAR(255) DEFAULT NULL COMMENT 'URL Webhook Sistem Luar',
  `outbound_key` VARCHAR(100) DEFAULT NULL COMMENT 'API Key untuk keluar ke Sistem Luar',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Audit Log Notifikasi
CREATE TABLE IF NOT EXISTS `notifikasi_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `disposisi_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `channel` ENUM('internal', 'telegram', 'whatsapp') NOT NULL,
  `recipient` VARCHAR(100),
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `error_msg` TEXT,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (disposisi_id) REFERENCES disposisi(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update Tabel Users (Gunakan ALTER untuk menambah field jika belum ada)
-- Kita cek dulu apakah kolom sudah ada di runtime, tapi di SQL kita sediakan command-nya
ALTER TABLE `users` ADD COLUMN `telegram_id` VARCHAR(50) DEFAULT NULL AFTER `role`;
ALTER TABLE `users` ADD COLUMN `no_hp` VARCHAR(20) DEFAULT NULL AFTER `telegram_id`;

SET FOREIGN_KEY_CHECKS = 1;
