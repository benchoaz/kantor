-- Migration 002: Add e-Kinerja Tables and Status Tracking
-- This migration adds complete e-Kinerja ASN reporting functionality
-- Execute this script after 001_add_file_hash.sql

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Add status_ekinerja column to kegiatan table
ALTER TABLE kegiatan 
ADD COLUMN status_ekinerja ENUM('belum', 'sudah', 'tidak') DEFAULT 'belum' AFTER created_by;

-- 2. Create output_kinerja table (managed by Admin)
CREATE TABLE IF NOT EXISTS output_kinerja (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bidang_id INT NOT NULL,
    nama_output VARCHAR(255) NOT NULL,
    deskripsi TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bidang_id) REFERENCES bidang(id) ON DELETE CASCADE,
    INDEX idx_bidang (bidang_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Create laporan_ekinerja table
CREATE TABLE IF NOT EXISTS laporan_ekinerja (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kegiatan_id INT NOT NULL UNIQUE,
    output_kinerja_id INT NOT NULL,
    uraian_singkat TEXT NULL,
    teks_bkn TEXT NOT NULL,
    status ENUM('draft', 'siap') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id) ON DELETE CASCADE,
    FOREIGN KEY (output_kinerja_id) REFERENCES output_kinerja(id) ON DELETE RESTRICT,
    INDEX idx_status (status),
    INDEX idx_kegiatan (kegiatan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Insert sample output_kinerja data for each bidang
-- These are examples, Admin can manage these via the UI
INSERT INTO output_kinerja (bidang_id, nama_output, deskripsi) VALUES 
(1, 'terlaksananya koordinasi administrasi sekretariat', 'Kegiatan koordinasi dan administrasi sekretariat'),
(2, 'terlaksananya rapat koordinasi pemerintahan', 'Rapat dan koordinasi bidang pemerintahan'),
(2, 'terlaksananya kegiatan pelayanan administrasi kependudukan', 'Pelayanan administrasi masyarakat'),
(3, 'terlaksananya kegiatan pembangunan infrastruktur', 'Kegiatan pembangunan dan ekonomi'),
(3, 'terlaksananya monitoring pasar dan UMKM', 'Monitoring ekonomi rakyat'),
(4, 'terlaksananya kegiatan posyandu', 'Pelayanan kesehatan masyarakat'),
(4, 'terlaksananya kegiatan pembinaan sosial', 'Pembinaan kesejahteraan rakyat'),
(5, 'terlaksananya patroli keamanan dan ketertiban', 'Kegiatan patroli linmas dan ketertiban');

SET FOREIGN_KEY_CHECKS = 1;

-- Notes:
-- - status_ekinerja: 'belum' = not created yet, 'sudah' = already created
-- - laporan_ekinerja.status: 'draft' = in progress, 'siap' = ready for BKN upload
-- - teks_bkn contains formatted Indonesian text ready to copy-paste to BKN
