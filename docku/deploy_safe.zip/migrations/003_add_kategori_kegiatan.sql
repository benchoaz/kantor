-- Migration 003: Add Kategori Kegiatan for SKK & SINCAN Reporting
-- Adds activity category classification for better report filtering

SET FOREIGN_KEY_CHECKS = 0;

-- Add kategori column to kegiatan table
ALTER TABLE kegiatan 
ADD COLUMN kategori ENUM(
    'pelayanan_publik',
    'koordinasi', 
    'pembinaan_wilayah',
    'trantibum',
    'pembangunan',
    'pemberdayaan_masyarakat'
) NULL AFTER tipe_kegiatan;

SET FOREIGN_KEY_CHECKS = 1;

-- Notes:
-- - Column is nullable for backward compatibility with existing data
-- - Can be filled gradually by admin/operator
-- - Categories based on SKK Kecamatan and SINCAN reporting standards
-- 
-- Category descriptions:
-- pelayanan_publik: Administrasi kependudukan, surat-menyurat, perizinan
-- koordinasi: Rapat, rakor, apel, briefing
-- pembinaan_wilayah: Musrenbang, monitoring desa, pembinaan RT/RW
-- trantibum: Patroli, penertiban, pengawasan keamanan
-- pembangunan: Monitoring fisik, infrastruktur, ADD/DD
-- pemberdayaan_masyarakat: PKK, Posyandu, UMKM, kegiatan sosial
