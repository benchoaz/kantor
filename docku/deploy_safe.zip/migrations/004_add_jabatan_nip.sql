-- Migration 004: Add Jabatan & NIP to Users
-- Adds position (jabatan) and civil servant ID (NIP) fields for proper organizational structure

SET FOREIGN_KEY_CHECKS = 0;

-- Add jabatan and nip columns to users table
ALTER TABLE users 
ADD COLUMN jabatan VARCHAR(100) NULL AFTER role,
ADD COLUMN nip VARCHAR(20) NULL AFTER jabatan;

-- Add index for faster queries
CREATE INDEX idx_jabatan ON users(jabatan);

SET FOREIGN_KEY_CHECKS = 1;

-- Notes:
-- jabatan: Position/title in kecamatan organization
-- nip: Nomor Induk Pegawai (Civil Servant ID Number)
-- Both nullable to support existing users and flexibility
--
-- Organizational Structure:
-- 1. Camat
-- 2. Sekretaris Camat (Sekcam)
--    - Kasubbag Perencanaan dan Keuangan
--    - Kasubbag Umum dan Kepegawaian
--    - Staf Sekretariat
-- 3. Kasi Pemerintahan + Staf
-- 4. Kasi Ekonomi & Pembangunan + Staf
-- 5. Kasi Kesejahteraan Rakyat + Staf
-- 6. Kasi Trantibum + Staf
