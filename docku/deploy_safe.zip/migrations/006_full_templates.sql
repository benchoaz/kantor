-- Insert FULL Compliance Templates (All 65 templates)
-- Based on: PP 30/2019, PermenPANRB 6/2022, Pedoman Output ASN BKN

-- Set existing to inactive first
UPDATE output_kinerja SET is_active = 0;

-- ========================================
-- STAF (25 templates) - Teknis & Operasional
-- Kata kerja: terlaksananya, tersusunnya, terdokumentasinya, terinputnya
-- ========================================

INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum, deskripsi) VALUES

-- Dokumentasi (10 templates)
('Terlaksananya dokumentasi kegiatan pelayanan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi kegiatan pelayanan publik'),
('Terlaksananya dokumentasi kegiatan pemerintahan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi kegiatan administrasi pemerintahan'),
('Terlaksananya dokumentasi kegiatan kesejahteraan rakyat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi kegiatan kesra'),
('Terlaksananya dokumentasi kegiatan ekonomi dan pembangunan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi kegiatan ekbang'),
('Terlaksananya dokumentasi kegiatan ketertiban dan ketentraman.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi kegiatan trantibum'),
('Terlaksananya dokumentasi rapat koordinasi kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi rapat/rakor'),
('Terlaksananya dokumentasi pengaduan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi laporan pengaduan'),
('Terlaksananya dokumentasi tindak lanjut pengaduan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi follow-up pengaduan'),
('Terlaksananya dokumentasi monitoring kegiatan di bidang terkait.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Monitoring pelaksanaan kegiatan'),
('Terlaksananya dokumentasi kegiatan pembinaan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pembinaan & pemberdayaan masyarakat'),

-- Penyusunan (10 templates)
('Tersusunnya laporan kegiatan pemerintahan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan kegiatan administrasi'),
('Tersusunnya laporan kegiatan pelayanan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan pelayanan publik'),
('Tersusunnya laporan kegiatan kesejahteraan rakyat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan kesra'),
('Tersusunnya laporan kegiatan ekonomi dan pembangunan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan ekbang'),
('Tersusunnya dokumentasi administrasi kegiatan di bidang terkait.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Administrasi kegiatan bidang'),
('Tersusunnya surat undangan kegiatan kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Surat undangan resmi'),
('Tersusunnya notulen rapat di lingkungan kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Notulen rapat/rakor'),
('Tersusunnya laporan monitoring pelaksanaan kegiatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan hasil monitoring'),
('Tersusunnya laporan pelayanan administrasi kependudukan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan adminduk'),
('Tersusunnya laporan pelayanan perizinan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan perizinan'),

-- Input Data (5 templates)
('Terinputnya data kegiatan ke sistem informasi kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Input data ke sistem'),
('Terinputnya data pelayanan masyarakat ke sistem.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Input data pelayanan'),
('Terdokumentasinya data kegiatan pemerintahan di bidang terkait.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dokumentasi data bidang'),
('Tersusunnya laporan kegiatan pemberdayaan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan pemberdayaan'),
('Terlaksananya dokumentasi kegiatan sosial kemasyarakatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Kegiatan sosial masyarakat');

-- ========================================
-- KASI (18 templates) - Koordinatif & Pengendalian
-- Kata kerja: terlaksananya koordinasi, terkendalinya, terfasilitasinya
-- ========================================

INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum, deskripsi) VALUES

-- Koordinasi (6 templates)
('Terlaksananya koordinasi pelaksanaan kegiatan pemerintahan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi kegiatan pemerintahan'),
('Terlaksananya koordinasi pelaksanaan kegiatan pelayanan masyarakat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi pelayanan'),
('Terlaksananya koordinasi pelaksanaan kegiatan kesejahteraan rakyat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi kesra'),
('Terlaksananya koordinasi pelaksanaan kegiatan ekonomi dan pembangunan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi ekbang'),
('Terlaksananya koordinasi pelaksanaan kegiatan ketertiban dan ketentraman pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi trantibum'),
('Terlaksananya koordinasi penanganan pengaduan masyarakat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi pengaduan'),

-- Pengendalian (5 templates)
('Terkendalinya pelaksanaan kegiatan pemerintahan pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian kegiatan'),
('Terkendalinya pelaksanaan kegiatan pelayanan masyarakat pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian pelayanan'),
('Terkendalinya pelaksanaan kegiatan di bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian bidang'),
('Terkendalinya pelayanan administrasi pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian administrasi'),
('Terlaksananya monitoring dan evaluasi kegiatan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Monev kegiatan bidang'),

-- Fasilitasi (5 templates)
('Terfasilitasinya pelaksanaan kegiatan pemerintahan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Fasilitasi kegiatan'),
('Terfasilitasinya pelaksanaan kegiatan pelayanan masyarakat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Fasilitasi pelayanan'),
('Terfasilitasinya koordinasi dengan instansi terkait pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Fasilitasi koordinasi eksternal'),
('Terfasilitasinya penyelesaian permasalahan teknis pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Problem solving teknis'),
('Terlaksananya pembinaan teknis kepada staf pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pembinaan staf'),

-- Evaluasi & Pelaporan (2 templates)
('Tersusunnya laporan evaluasi pelaksanaan kegiatan pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan evaluasi'),
('Terlaksananya koordinasi monitoring kegiatan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi monitoring');

-- ========================================
-- SEKCAM (12 templates) - Manajerial & Lintas Bidang
-- Kata kerja: tersinkronisasinya, terfasilitasinya, terkendalinya
-- ========================================

INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum, deskripsi) VALUES

-- Sinkronisasi (4 templates)
('Tersinkronisasinya pelaksanaan kegiatan lintas bidang di lingkungan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Sinkronisasi lintas bidang'),
('Tersinkronisasinya administrasi kegiatan di lingkungan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Sinkronisasi administrasi'),
('Tersinkronisasinya perencanaan dan penganggaran kegiatan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Sinkronisasi perencanaan'),
('Tersinkronisasinya pelaporan kinerja kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Sinkronisasi pelaporan'),

-- Fasilitasi & Pengendalian (5 templates)
('Terlaksananya fasilitasi dan pengendalian administrasi kegiatan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Fasilitasi & pengendalian'),
('Terfasilitasinya koordinasi lintas bidang di lingkungan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Fasilitasi koordinasi'),
('Terkendalinya pelaksanaan kegiatan lintas bidang di kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian lintas bidang'),
('Terlaksananya pengendalian administrasi umum dan kepegawaian kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian umum & kepegawaian'),
('Terfasilitasinya dukungan administratif kepada pimpinan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Dukungan pimpinan'),

-- Administrasi & Evaluasi (3 templates)
('Tersusunnya laporan administrasi dan keuangan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan adm & keuangan'),
('Terlaksananya koordinasi monitoring pelaksanaan kegiatan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi monitoring'),
('Terfasilitasinya evaluasi kinerja lintas bidang di kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Evaluasi kinerja');

-- ========================================
-- CAMAT (10 templates) - Kepemimpinan & Penetapan
-- Kata kerja: terlaksananya pembinaan, ditetapkannya, pengendalian
-- ========================================

INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum, deskripsi) VALUES

-- Pembinaan & Pengendalian (4 templates)
('Terlaksananya pembinaan dan pengendalian penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pembinaan & pengendalian'),
('Terlaksananya pembinaan aparatur kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pembinaan ASN'),
('Terlaksananya pengendalian dan evaluasi kinerja kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pengendalian & evaluasi'),
('Terlaksananya pembinaan dan pengayoman masyarakat di wilayah kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pembinaan masyarakat'),

-- Penetapan & Arahan (2 templates)
('Ditetapkannya arah kebijakan dalam penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Penetapan kebijakan'),
('Ditetapkannya prioritas program dan kegiatan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Penetapan prioritas'),

-- Koordinasi Strategis (2 templates)
('Terlaksananya koordinasi strategis dengan instansi terkait.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Koordinasi eksternal'),
('Terlaksananya pembinaan dan koordinasi kepada desa/kelurahan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Pembinaan desa'),

-- Evaluasi & Pelaporan (2 templates)
('Terlaksananya evaluasi penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Evaluasi penyelenggaraan'),
('Tersusunnya laporan penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022', 'Laporan penyelenggaraan');

-- Summary Check
SELECT level_jabatan, COUNT(*) as jumlah 
FROM output_kinerja 
WHERE is_active = 1 
GROUP BY level_jabatan;
