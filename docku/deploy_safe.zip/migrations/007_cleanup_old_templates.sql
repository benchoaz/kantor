-- ================================================================
-- SAFE CLEANUP: Non-Compliance Output Templates
-- ================================================================
-- Purpose: Soft-delete old output templates without level_jabatan
-- Safe: Does NOT delete data, only marks as inactive
-- Date: 2025-12-31
-- ================================================================

-- ========================================
-- STEP 1: DEPENDENCY CHECK (Run First!)
-- ========================================

-- Check if any e-Kinerja reports use old templates
SELECT 
    COUNT(*) as total_reports_affected,
    COUNT(DISTINCT le.id) as unique_reports
FROM laporan_ekinerja le
JOIN output_kinerja ok ON le.output_kinerja_id = ok.id
WHERE ok.level_jabatan IS NULL OR ok.level_jabatan = '';

-- Expected result: 
-- If total_reports_affected = 0 → SAFE to proceed
-- If total_reports_affected > 0 → Review before proceeding

-- ========================================
-- STEP 2: PREVIEW AFFECTED TEMPLATES
-- ========================================

-- See which templates will be affected
SELECT 
    id,
    COALESCE(bidang_id, 0) as bidang_id,
    nama_output,
    level_jabatan,
    is_active,
    created_at
FROM output_kinerja
WHERE (level_jabatan IS NULL OR level_jabatan = '')
AND is_active = 1;

-- Note: These templates will be set to is_active = 0

-- ========================================
-- STEP 3: SAFE SOFT DELETE (RECOMMENDED)
-- ========================================

-- Deactivate old templates without level_jabatan
-- This is SAFE - does NOT delete, only hides from dropdown
UPDATE output_kinerja 
SET 
    is_active = 0,
    updated_at = CURRENT_TIMESTAMP
WHERE (level_jabatan IS NULL OR level_jabatan = '')
AND is_active = 1;

-- ========================================
-- STEP 4: VERIFICATION
-- ========================================

-- Verify cleanup was successful
SELECT 
    level_jabatan,
    is_active,
    COUNT(*) as total
FROM output_kinerja
GROUP BY level_jabatan, is_active
ORDER BY level_jabatan, is_active;

-- Expected result:
-- level_jabatan | is_active | total
-- --------------|-----------|-------
-- staf          | 1         | 25
-- kasi          | 1         | 18
-- sekcam        | 1         | 12
-- camat         | 1         | 10
-- NULL          | 0         | X    (old templates - now inactive)

-- ========================================
-- STEP 5: COUNT ACTIVE COMPLIANCE TEMPLATES
-- ========================================

-- Should show 65 active compliance templates
SELECT 
    level_jabatan,
    COUNT(*) as active_templates
FROM output_kinerja
WHERE is_active = 1
GROUP BY level_jabatan
ORDER BY FIELD(level_jabatan, 'staf', 'kasi', 'sekcam', 'camat');

-- Expected:
-- staf   → 25
-- kasi   → 18
-- sekcam → 12
-- camat  → 10
-- TOTAL  → 65

-- ========================================
-- OPTIONAL: ROLLBACK (If Needed)
-- ========================================

-- If you need to undo the cleanup, run this:
-- UPDATE output_kinerja 
-- SET is_active = 1 
-- WHERE (level_jabatan IS NULL OR level_jabatan = '');

-- ================================================================
-- NOTES FOR ADMIN:
-- ================================================================
-- 1. Run STEP 1 first to check dependencies
-- 2. If safe (count = 0), proceed with STEP 3
-- 3. If count > 0, consider migrating those reports first
-- 4. Soft delete is REVERSIBLE - data is preserved
-- 5. Old templates won't appear in user dropdowns after cleanup
-- 6. Existing e-Kinerja reports will still function normally
-- ================================================================

-- End of script
