-- Migration 006: e-Kinerja Compliance System
-- Basis: PP 30/2019, PermenPANRB 6/2022, dan Pedoman Output ASN BKN
-- Menambahkan level jabatan dan compliance tracking ke output_kinerja

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Add compliance columns to output_kinerja
ALTER TABLE output_kinerja 
ADD COLUMN level_jabatan ENUM('staf', 'kasi', 'sekcam', 'camat') NULL AFTER nama_output,
ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER level_jabatan,
ADD COLUMN dasar_hukum VARCHAR(255) NULL COMMENT 'PP 30/2019, PermenPANRB 6/2022' AFTER is_active,
ADD COLUMN created_by INT NULL AFTER dasar_hukum,
ADD COLUMN updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- 2. Add indexes for performance
CREATE INDEX idx_level_jabatan ON output_kinerja(level_jabatan);
CREATE INDEX idx_active ON output_kinerja(is_active);

-- 3. Set existing outputs to inactive (will be replaced with compliance templates)
UPDATE output_kinerja SET is_active = 0;

-- 4. Insert COMPLIANCE TEMPLATES per Jabatan Level

-- ========================================
-- STAF (25 templates) - Teknis & Operasional
-- ========================================
INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum) VALUES
-- Dokumentasi
('Terlaksananya dokumentasi kegiatan pelayanan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi kegiatan pemerintahan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi kegiatan kesejahteraan rakyat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi kegiatan ekonomi dan pembangunan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi kegiatan ketertiban dan ketentraman.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi rapat koordinasi kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Penyusunan
('Tersusunnya laporan kegiatan pemerintahan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan kegiatan pelayanan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan kegiatan kesejahteraan rakyat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan kegiatan ekonomi dan pembangunan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya dokumentasi administrasi kegiatan di bidang terkait.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Input Data
('Terinputnya data kegiatan ke sistem informasi kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terinputnya data pelayanan masyarakat ke sistem.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terdokumentasinya data kegiatan pemerintahan di bidang terkait.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Pengaduan & Pelayanan
('Terlaksananya dokumentasi pengaduan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi tindak lanjut pengaduan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan pelayanan administrasi kependudukan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan pelayanan perizinan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Monitoring
('Terlaksananya dokumentasi monitoring kegiatan di bidang terkait.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan monitoring pelaksanaan kegiatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Administrasi Umum
('Tersusunnya surat undangan kegiatan kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya notulen rapat di lingkungan kecamatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi kegiatan pembinaan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan kegiatan pemberdayaan masyarakat.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya dokumentasi kegiatan sosial kemasyarakatan.', NULL, 'staf', 1, 'PP 30/2019, PermenPANRB 6/2022');

-- ========================================
-- KASI (18 templates) - Koordinatif & Pengendalian
-- ========================================
INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum) VALUES
-- Koordinasi
('Terlaksananya koordinasi pelaksanaan kegiatan pemerintahan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya koordinasi pelaksanaan kegiatan pelayanan masyarakat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya koordinasi pelaksanaan kegiatan kesejahteraan rakyat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya koordinasi pelaksanaan kegiatan ekonomi dan pembangunan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya koordinasi pelaksanaan kegiatan ketertiban dan ketentraman pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Pengendalian
('Terkendalinya pelaksanaan kegiatan pemerintahan pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terkendalinya pelaksanaan kegiatan pelayanan masyarakat pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terkendalinya pelaksanaan kegiatan di bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Fasilitasi
('Terfasilitasinya pelaksanaan kegiatan pemerintahan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terfasilitasinya pelaksanaan kegiatan pelayanan masyarakat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terfasilitasinya koordinasi dengan instansi terkait pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Monitoring & Evaluasi
('Terlaksananya monitoring dan evaluasi kegiatan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan evaluasi pelaksanaan kegiatan pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya koordinasi monitoring kegiatan pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Pembinaan Teknis
('Terlaksananya pembinaan teknis kepada staf pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terfasilitasinya penyelesaian permasalahan teknis pada bidang.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Pengaduan & Pelayanan Tingkat Kasi
('Terlaksananya koordinasi penanganan pengaduan masyarakat pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terkendalinya pelayanan administrasi pada bidang terkait.', NULL, 'kasi', 1, 'PP 30/2019, PermenPANRB 6/2022');

-- ========================================
-- SEKCAM (12 templates) - Manajerial & Lintas Bidang
-- ========================================
INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum) VALUES
-- Sinkronisasi
('Tersinkronisasinya pelaksanaan kegiatan lintas bidang di lingkungan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersinkronisasinya administrasi kegiatan di lingkungan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersinkronisasinya perencanaan dan penganggaran kegiatan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Fasilitasi & Pengendalian
('Terlaksananya fasilitasi dan pengendalian administrasi kegiatan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terfasilitasinya koordinasi lintas bidang di lingkungan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terkendalinya pelaksanaan kegiatan lintas bidang di kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Administrasi & Perencanaan
('Tersusunnya laporan administrasi dan keuangan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya pengendalian administrasi umum dan kepegawaian kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersinkronisasinya pelaporan kinerja kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Monitoring Manajerial
('Terlaksananya koordinasi monitoring pelaksanaan kegiatan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terfasilitasinya evaluasi kinerja lintas bidang di kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Dukungan Pimpinan
('Terfasilitasinya dukungan administratif kepada pimpinan kecamatan.', NULL, 'sekcam', 1, 'PP 30/2019, PermenPANRB 6/2022');

-- ========================================
-- CAMAT (10 templates) - Kepemimpinan & Penetapan
-- ========================================
INSERT INTO output_kinerja (nama_output, bidang_id, level_jabatan, is_active, dasar_hukum) VALUES
-- Pembinaan & Pengendalian
('Terlaksananya pembinaan dan pengendalian penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya pembinaan aparatur kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya pengendalian dan evaluasi kinerja kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Penetapan & Arahan
('Ditetapkannya arah kebijakan dalam penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Ditetapkannya prioritas program dan kegiatan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Koordinasi Strategis
('Terlaksananya koordinasi strategis dengan instansi terkait.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Terlaksananya pembinaan dan koordinasi kepada desa/kelurahan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Evaluasi & Pelaporan
('Terlaksananya evaluasi penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),
('Tersusunnya laporan penyelenggaraan pemerintahan kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022'),

-- Pembinaan Masyarakat
('Terlaksananya pembinaan dan pengayoman masyarakat di wilayah kecamatan.', NULL, 'camat', 1, 'PP 30/2019, PermenPANRB 6/2022');

SET FOREIGN_KEY_CHECKS = 1;

-- Summary:
-- Total: 65 templates compliance
-- - Staf: 25 templates
-- - Kasi: 18 templates  
-- - Sekcam: 12 templates
-- - Camat: 10 templates
--
-- Basis Hukum: PP 30/2019, PermenPANRB 6/2022
-- Prinsip: Sesuai jabatan, Terukur, Dapat dibuktikan, Singkat
