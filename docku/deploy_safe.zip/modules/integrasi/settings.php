<?php
// modules/integrasi/settings.php
$page_title = 'Pengaturan Integrasi';
$active_page = 'integrasi';

require_once '../../config/database.php';
require_once '../../includes/header.php';

// Access Control: Admin Only
if ($_SESSION['role'] !== 'admin') {
    echo "<script>alert('Akses Ditolak'); window.location='../../index.php';</script>";
    exit;
}

// Handle Form Submission
$message = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            $redirectParams = '';
            
            if ($_POST['action'] === 'generate_inbound') {
                // Generate new Inbound Key
                $label = trim(htmlspecialchars($_POST['label']));
                $newKey = bin2hex(random_bytes(32)); // 64 chars secure key
                
                $stmt = $pdo->prepare("INSERT INTO integrasi_config (label, inbound_key, is_active) VALUES (?, ?, 1)");
                if ($stmt->execute([$label, $newKey])) {
                    $redirectParams = 'msg=success&txt=API Key Inbound baru berhasil dibuat';
                } else {
                    $redirectParams = 'msg=error&txt=Gagal membuat API Key';
                }
            } elseif ($_POST['action'] === 'update_outbound') {
                // Update Outbound Config for an existing integration
                $id = intval($_POST['id']);
                $url = filter_var($_POST['outbound_url'], FILTER_SANITIZE_URL);
                $key = trim($_POST['outbound_key']);
                
                $stmt = $pdo->prepare("UPDATE integrasi_config SET outbound_url = ?, outbound_key = ? WHERE id = ?");
                if ($stmt->execute([$url, $key, $id])) {
                    $redirectParams = 'msg=success&txt=Konfigurasi Outbound berhasil disimpan';
                } else {
                    $redirectParams = 'msg=error&txt=Gagal menyimpan konfigurasi';
                }
            } elseif ($_POST['action'] === 'delete') {
                $id = intval($_POST['id']);
                $stmt = $pdo->prepare("DELETE FROM integrasi_config WHERE id = ?");
                if ($stmt->execute([$id])) {
                    $redirectParams = 'msg=success&txt=Integrasi berhasil dihapus';
                }
            } elseif ($_POST['action'] === 'update_telegram') {
                $token = trim($_POST['bot_token']);
                
                // Check if exists
                $stmtCheck = $pdo->prepare("SELECT id FROM integrasi_config WHERE label = 'Telegram' LIMIT 1");
                $stmtCheck->execute();
                $existingId = $stmtCheck->fetchColumn();
                
                if ($existingId) {
                    $stmt = $pdo->prepare("UPDATE integrasi_config SET outbound_key = ?, is_active = 1 WHERE id = ?");
                    $stmt->execute([$token, $existingId]);
                } else {
                    $stmt = $pdo->prepare("INSERT INTO integrasi_config (label, outbound_key, is_active, inbound_key) VALUES ('Telegram', ?, 1, 'TG-BOT')");
                    $stmt->execute([$token]);
                }
                $redirectParams = 'msg=success&txt=Konfigurasi Bot Telegram berhasil disimpan';
            }
            
            // Redirect to self to prevent form resubmission (PRG Pattern)
            if ($redirectParams) {
                header("Location: settings.php?" . $redirectParams);
                exit;
            }
            
        } catch (PDOException $e) {
            $errorMsg = urlencode("Database Error: " . $e->getMessage());
            header("Location: settings.php?msg=error&txt=" . $errorMsg);
            exit;
        }
    }
}

// Handle Flash Messages
$message = '';
$msgType = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'success') {
        $msgType = 'success';
        $message = htmlspecialchars($_GET['txt'] ?? 'Operasi berhasil');
    } else {
        $msgType = 'danger';
        $message = htmlspecialchars($_GET['txt'] ?? 'Terjadi kesalahan');
    }
}

// Fetch Existing Integrations
$integrations = $pdo->query("SELECT * FROM integrasi_config ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

// Build endpoint URL for display
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$scriptPath = $_SERVER['SCRIPT_NAME'];
$basePath = preg_replace('#/modules/integrasi/.*$#', '', $scriptPath);
$endpointUrl = $protocol . '://' . $host . $basePath . '/api/v1/disposisi/receive.php';
?>

<div class="row fade-in">
    <div class="col-md-12 mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold mb-1">🔌 Pengaturan Integrasi API</h4>
                <p class="text-muted small">Kelola konektivitas Inbound (SuratQu -> Docku) dan Outbound (Docku -> SuratQu)</p>
            </div>
            <div>
                <a href="tutorial.php" class="btn btn-outline-info btn-sm me-2">
                    <i class="bi bi-book me-1"></i> Panduan
                </a>
                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalAddInbound">
                    <i class="bi bi-plus-lg me-1"></i> Buat Kunci Baru
                </button>
            </div>
        </div>
    </div>

    <?php 
    $stmtT = $pdo->prepare("SELECT outbound_key FROM integrasi_config WHERE label = 'Telegram' LIMIT 1");
    $stmtT->execute();
    $botToken = $stmtT->fetchColumn();
    ?>
    <div class="col-md-12 mb-4 animate-up">
        <div class="card card-modern border-0 shadow-sm overflow-hidden" style="border-left: 5px solid #0088cc !important;">
            <div class="card-body p-4">
                <div class="row align-items-center">
                    <div class="col-md-7 mb-3 mb-md-0">
                        <h5 class="fw-bold mb-1 d-flex align-items-center">
                            <i class="bi bi-telegram text-info fs-4 me-2"></i> Notifikasi Telegram Pimpinan
                        </h5>
                        <p class="text-muted small mb-0">Kirim pemberitahuan otomatis ke HP Pimpinan (Camat/Admin) via bot Telegram saat tugas di lapangan selesai.</p>
                    </div>
                    <div class="col-md-5">
                        <form method="POST" id="formTelegramBot">
                            <div class="input-group">
                                <input type="hidden" name="action" value="update_telegram">
                                <input type="password" name="bot_token" class="form-control" placeholder="BOT Token Telegram" value="<?= htmlspecialchars($botToken ?? '') ?>">
                                <button type="submit" class="btn btn-info text-white fw-bold px-3">Simpan</button>
                                <button type="button" id="btnTestTelegram" class="btn btn-warning fw-bold px-3" <?= $botToken ? '' : 'disabled' ?>>
                                    <i class="bi bi-send-fill me-1"></i>Test
                                </button>
                            </div>
                        </form>
                        <div id="testTelegramResult" class="mt-2" style="display:none;"></div>
                        <div class="form-text mt-1 small">
                            Dapatkan token di <a href="https://t.me/botfather" target="_blank" class="text-decoration-none">@BotFather</a>. 
                            Pastikan Anda sudah daftar <b>Chat ID</b> di <a href="../../profil.php" class="text-decoration-none">Profil</a>.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Inbound List -->
    <div class="col-md-12">
        <?php if (count($integrations) > 0): ?>
            <div class="row g-4">
                <?php foreach ($integrations as $row): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 card-modern border-0 shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <h5 class="fw-bold text-primary mb-0"><?= htmlspecialchars($row['label']) ?></h5>
                                    <span class="badge bg-success bg-opacity-10 text-success">Active</span>
                                </div>
                                
                                <!-- Endpoint URL Section -->
                                <div class="alert alert-info mb-3 py-2 px-3">
                                    <label class="small fw-bold d-block mb-1">📍 Endpoint URL</label>
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control font-monospace bg-white" 
                                               value="<?= htmlspecialchars($endpointUrl) ?>" readonly id="endpoint_<?= $row['id'] ?>">
                                        <button class="btn btn-outline-primary" type="button" onclick="copyToClipboard('endpoint_<?= $row['id'] ?>')">
                                            <i class="bi bi-clipboard"></i>
                                        </button>
                                    </div>
                                    <div class="form-text small mt-1">URL endpoint untuk menerima disposisi dari sistem eksternal</div>
                                </div>
                                
                                <!-- Connection Test Section -->
                                <div class="mb-3">
                                    <button type="button" class="btn btn-sm btn-outline-success w-100" 
                                            onclick="testConnection(<?= $row['id'] ?>)" id="testBtn_<?= $row['id'] ?>">
                                        <i class="bi bi-plug"></i> Test Koneksi
                                    </button>
                                    <div id="testResult_<?= $row['id'] ?>" class="mt-2" style="display:none;"></div>
                                </div>
                                
                                <!-- Inbound Section -->
                                <div class="bg-light p-3 rounded-3 mb-3">
                                    <label class="small text-muted fw-bold d-block mb-1">🔑 Inbound API Key</label>
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control font-monospace text-muted bg-white" 
                                               value="<?= htmlspecialchars($row['inbound_key']) ?>" readonly id="key_<?= $row['id'] ?>">
                                        <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('key_<?= $row['id'] ?>')">
                                            <i class="bi bi-clipboard"></i>
                                        </button>
                                    </div>
                                    <div class="form-text small mt-1">Gunakan key ini di header <code>X-API-KEY</code> saat POST ke endpoint</div>
                                </div>
                                
                                <!-- Outbound Section -->
                                <form method="POST">
                                    <input type="hidden" name="action" value="update_outbound">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <div class="mb-3">
                                        <label class="small text-muted fw-bold d-block mb-1">📡 Outbound Webhook URL</label>
                                        <input type="url" name="outbound_url" class="form-control form-control-sm" 
                                               placeholder="https://suratqu.go.id/api/callback" value="<?= htmlspecialchars($row['outbound_url'] ?? '') ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="small text-muted fw-bold d-block mb-1">🔐 Outbound Key (Optional)</label>
                                        <input type="text" name="outbound_key" class="form-control form-control-sm" 
                                               placeholder="Secret Key Sistem Luar" value="<?= htmlspecialchars($row['outbound_key'] ?? '') ?>">
                                    </div>
                                    <div class="d-flex justify-content-between mt-4">
                                        <button type="submit" class="btn btn-sm btn-outline-primary w-100 me-2">Simpan Config</button>
                                        <button type="button" class="btn btn-sm btn-outline-danger" 
                                                onclick="confirmDelete(<?= $row['id'] ?>, '<?= htmlspecialchars($row['label']) ?>')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <img src="../../assets/img/empty.svg" alt="Empty" style="width: 120px; opacity: 0.5;">
                <p class="text-muted mt-3">Belum ada integrasi yang dikonfigurasi.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Add Inbound -->
<div class="modal fade" id="modalAddInbound" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <input type="hidden" name="action" value="generate_inbound">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Buat Kunci API Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Nama Sistem / Label</label>
                    <input type="text" name="label" class="form-control" placeholder="Contoh: SuratQu, E-Office, SiMaya" required>
                    <div class="form-text">Beri nama untuk mengidentifikasi asal request.</div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Generate API Key</button>
            </div>
        </form>
    </div>
</div>

<!-- Form Delete Hidden -->
<form id="formDelete" method="POST" style="display:none;">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function copyToClipboard(elementId) {
    const copyText = document.getElementById(elementId);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value).then(() => {
        // Show toast notification instead of alert
        const toastHtml = '<div class="alert alert-success alert-dismissible fade show position-fixed" style="top:20px;right:20px;z-index:9999;" role="alert">'
            + '<i class="bi bi-check-circle me-2"></i>Tersalin ke clipboard!'
            + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        document.body.insertAdjacentHTML('beforeend', toastHtml);
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts[alerts.length - 1]?.remove();
        }, 3000);
    });
}

function confirmDelete(id, label) {
    if(confirm('Yakin ingin menghapus integrasi "'+label+'"? Akses dari sistem tersebut akan terputus.')) {
        document.getElementById('deleteId').value = id;
        document.getElementById('formDelete').submit();
    }
}

function testConnection(id) {
    const btn = document.getElementById('testBtn_' + id);
    const resultDiv = document.getElementById('testResult_' + id);
    
    // Disable button and show loading
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Testing...';
    resultDiv.style.display = 'none';
    
    // Send AJAX request
    const formData = new FormData();
    formData.append('id', id);
    
    fetch('test_connection.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Show result
        resultDiv.style.display = 'block';
        
        if (data.status === 'success') {
            resultDiv.innerHTML = '<div class="alert alert-success alert-sm py-2 mb-0">'
                + '<i class="bi bi-check-circle me-1"></i> <strong>Berhasil!</strong><br>'
                + '<small>' + data.message + '</small>'
                + (data.details ? '<div class="mt-1 small"><code>' + JSON.stringify(data.details, null, 2) + '</code></div>' : '')
                + '</div>';
        } else {
            resultDiv.innerHTML = '<div class="alert alert-danger alert-sm py-2 mb-0">'
                + '<i class="bi bi-exclamation-triangle me-1"></i> <strong>Gagal!</strong><br>'
                + '<small>' + data.message + '</small>'
                + (data.http_code ? '<div class="mt-1 small">HTTP Code: ' + data.http_code + '</div>' : '')
                + (data.details ? '<div class="mt-1 small"><code>' + JSON.stringify(data.details, null, 2) + '</code></div>' : '')
                + '</div>';
        }
        
        // Re-enable button
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-plug"></i> Test Koneksi';
    })
    .catch(error => {
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = '<div class="alert alert-danger alert-sm py-2 mb-0">'
            + '<i class="bi bi-exclamation-triangle me-1"></i> <strong>Error!</strong><br>'
            + '<small>' + error.message + '</small></div>';
        
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-plug"></i> Test Koneksi';
    });
}

const btnTestTelegram = document.getElementById('btnTestTelegram');
if (btnTestTelegram) {
    btnTestTelegram.addEventListener('click', function() {
        const resultDiv = document.getElementById('testTelegramResult');
        
        btnTestTelegram.disabled = true;
        btnTestTelegram.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = '<div class="alert alert-info alert-sm py-2 mb-0"><i class="bi bi-hourglass-split me-1"></i> Menghubungi Telegram...</div>';
        
        fetch('test_telegram.php', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                resultDiv.innerHTML = '<div class="alert alert-success alert-sm py-2 mb-0">'
                    + '<i class="bi bi-check-circle-fill me-1"></i> <b>Berhasil!</b><br>'
                    + '<small>' + data.message + '</small></div>';
            } else {
                resultDiv.innerHTML = '<div class="alert alert-danger alert-sm py-2 mb-0">'
                    + '<i class="bi bi-exclamation-triangle-fill me-1"></i> <b>Gagal!</b><br>'
                    + '<small>' + data.message + '</small></div>';
            }
        })
        .catch(error => {
            resultDiv.innerHTML = '<div class="alert alert-danger alert-sm py-2 mb-0">'
                + '<i class="bi bi-bug me-1"></i> <b>Error:</b> ' + error.message + '</div>';
        })
        .finally(() => {
            btnTestTelegram.disabled = false;
            btnTestTelegram.innerHTML = '<i class="bi bi-send-fill me-1"></i>Test';
        });
    });
}
</script>

<?php require_once '../../includes/footer.php'; ?>
