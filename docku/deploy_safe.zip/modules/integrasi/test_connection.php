<?php
// modules/integrasi/test_connection.php
// AJAX endpoint untuk test koneksi API

header('Content-Type: application/json');

require_once '../../config/database.php';

// Access Control: Admin Only
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Akses ditolak']);
    exit;
}

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

// Get integration ID
$integration_id = intval($_POST['id'] ?? 0);

if (!$integration_id) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid integration ID']);
    exit;
}

try {
    // Get integration config
    $stmt = $pdo->prepare("SELECT * FROM integrasi_config WHERE id = ? LIMIT 1");
    $stmt->execute([$integration_id]);
    $config = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$config) {
        echo json_encode(['status' => 'error', 'message' => 'Integrasi tidak ditemukan']);
        exit;
    }
    
    // Build endpoint URL
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $baseUrl = $protocol . '://' . $host;
    
    // Get the base path (everything before /modules/integrasi/)
    $scriptPath = $_SERVER['SCRIPT_NAME']; // e.g., /Docku/modules/integrasi/test_connection.php
    $basePath = preg_replace('#/modules/integrasi/.*$#', '', $scriptPath);
    
    $endpointUrl = $basePath . '/api/v1/disposisi/receive.php';
    
    // Test 1: GET request to check endpoint availability
    $ch = curl_init($baseUrl . $endpointUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false, // For local development
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    if ($curlError) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Koneksi gagal: ' . $curlError,
            'endpoint' => $baseUrl . $endpointUrl
        ]);
        exit;
    }
    
    // Test 2: POST request with test payload and API key
    $testPayload = [
        'external_id' => 'TEST_' . time(),
        'perihal' => 'Test Koneksi dari Docku Settings',
        'instruksi' => 'Ini adalah test koneksi, data ini tidak akan disimpan',
        'tgl_disposisi' => date('Y-m-d H:i:s'),
        '_test_mode' => true // Flag to indicate this is a test
    ];
    
    $ch = curl_init($baseUrl . $endpointUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($testPayload),
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-API-KEY: ' . $config['inbound_key']
        ]
    ]);
    
    $postResponse = curl_exec($ch);
    $postHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $postCurlError = curl_error($ch);
    curl_close($ch);
    
    // Decode response
    $postData = json_decode($postResponse, true);
    
    // Determine success
    if ($postHttpCode === 201 && isset($postData['status']) && $postData['status'] === 'success') {
        // Success - delete the test record
        if (isset($postData['data']['docku_id'])) {
            $testId = intval($postData['data']['docku_id']);
            $pdo->prepare("DELETE FROM disposisi WHERE id = ?")->execute([$testId]);
        }
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Koneksi berhasil! API endpoint dapat menerima disposisi.',
            'endpoint' => $baseUrl . $endpointUrl,
            'http_code' => $postHttpCode,
            'details' => [
                'get_test' => 'OK (HTTP ' . $httpCode . ')',
                'post_test' => 'OK (HTTP ' . $postHttpCode . ')',
                'authentication' => 'Valid',
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]);
    } else {
        // Failed
        echo json_encode([
            'status' => 'error',
            'message' => 'Endpoint ditemukan tetapi gagal memproses request',
            'endpoint' => $baseUrl . $endpointUrl,
            'http_code' => $postHttpCode,
            'response' => $postData ?? $postResponse,
            'details' => [
                'get_test' => 'HTTP ' . $httpCode,
                'post_test' => 'HTTP ' . $postHttpCode,
                'curl_error' => $postCurlError
            ]
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
?>
