<?php
// Enable local error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'includes/auth.php';
require_once 'vendor/fpdf/fpdf.php';
require_once 'includes/pdf_base.php';
require_once 'includes/helpers.php';
require_login();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT k.*, b.nama_bidang, u.nama as pembuat 
                        FROM kegiatan k 
                        JOIN bidang b ON k.bidang_id = b.id 
                        JOIN users u ON k.created_by = u.id 
                        WHERE k.id = ?");
$stmt->execute([$id]);
$k = $stmt->fetch();

if (!$k) {
    die("Kegiatan tidak ditemukan.");
}

// Fetch photos with user attribution
$stmt_fotos = $pdo->prepare("SELECT fk.*, u.nama as contributor
                            FROM foto_kegiatan fk
                            LEFT JOIN users u ON fk.user_id = u.id
                            WHERE fk.kegiatan_id = ?
                            ORDER BY fk.uploaded_at ASC");
$stmt_fotos->execute([$id]);
$fotos = $stmt_fotos->fetchAll();

// Get unique contributors list
$contributors = array_unique(array_filter(array_column($fotos, 'contributor')));

// Fetch Kop Surat Settings (Safeguard)
try {
    $stmtS = $pdo->query("SELECT * FROM pengaturan LIMIT 1");
    $kop = $stmtS ? $stmtS->fetch() : false;
} catch (Exception $e) {
    $kop = false;
}

if (!$kop) {
    $kop = [
        'nama_instansi_1' => 'PEMERINTAH KABUPATEN PROBOLINGGO',
        'nama_instansi_2' => 'KECAMATAN BESUK',
        'alamat_1' => 'Jalan Raya Besuk No. 1, Besuk, Probolinggo',
        'alamat_2' => 'Email: kecamatan.besuk@probolinggokab.go.id',
        'nama_camat' => 'PUJA KURNIAWAN, S.STP., M.Si',
        'nip_camat' => '19800101 200001 1 001'
    ];
}

// 1. Get Orientation & Size from parameters
$orient = $_GET['orient'] ?? 'P';
$size = $_GET['size'] ?? 'F4';

// class PDF extends PDF_Base {} // Already defined in pdf_base, no need to redefine unless custom logic needed
if (!class_exists('PDF')) {
    class PDF extends PDF_Base {}
}

$pdf = new PDF($orient, 'mm', $size);
$pdf->setKop($kop);
$pdf->AliasNbPages();

// Set Dynamic Margins
if ($orient === 'P') {
    $pdf->SetMargins(40, 30, 30); // L:4, T:3, R:3 (Portrait Standard)
} else {
    $pdf->SetMargins(30, 40, 30); // T:4, L:3, R:3 (Landscape Standard)
}

$pdf->AddPage();

// 2. Title & Dynamic Type Label
$report_title = "LAPORAN HASIL";
$report_subtitle = "PELAKSANAAN TUGAS KEDINASAN";

if (!empty($k['kategori'])) {
    $report_subtitle = "PELAKSANAAN TUGAS " . strtoupper($k['kategori']);
}

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 8, $report_title, 0, 1, 'C');
$pdf->Cell(0, 8, $report_subtitle, 0, 1, 'C');
$pdf->Ln(10);

// Professional Reporting Sections
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'I. PENDAHULUAN', 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);
$pdf->SetX($pdf->GetLMargin() + 10);
$intro = "Dalam rangka menunjang efektivitas penyelenggaraan pemerintahan di tingkat Kecamatan, khususnya pada bidang " . $k['nama_bidang'] . ", telah dilaksanakan kegiatan " . $k['judul'] . " sebagai bagian dari pelaksanaan tugas pokok dan fungsi organisasi.";
$pdf->MultiCell(0, 7, $intro, 0, 'J');
$pdf->Ln(4);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'II. DASAR PELAKSANAAN', 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->Cell(0, 7, "1. Peraturan Pemerintah Nomor 17 Tahun 2018 tentang Kecamatan;", 0, 1, 'L');
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->Cell(0, 7, "2. Program Kerja " . ($kop['nama_instansi_2'] ?? 'Kecamatan Besuk') . " Tahun Anggaran " . date('Y', strtotime($k['tanggal'])) . ";", 0, 1, 'L');
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->Cell(0, 7, "3. Arahan Pimpinan dan Kebutuhan Pelayanan Wilayah.", 0, 1, 'L');
$pdf->Ln(4);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'III. WAKTU DAN TEMPAT', 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->Cell(50, 7, "Hari / Tanggal", 0, 0, 'L');
$pdf->Cell(5, 7, ":", 0, 0, 'C');
$pdf->Cell(0, 7, format_tanggal_indonesia($k['tanggal']), 0, 1, 'L');
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->Cell(50, 7, "Waktu", 0, 0, 'L');
$pdf->Cell(5, 7, ":", 0, 0, 'C');
$waktu_str = "-";
if (!empty($k['jam_mulai'])) {
    $waktu_str = date('H:i', strtotime($k['jam_mulai'])) . ' WIB';
    if (!empty($k['jam_selesai'])) {
        $waktu_str .= ' s/d ' . date('H:i', strtotime($k['jam_selesai'])) . ' WIB';
    } else {
        $waktu_str .= ' s/d Selesai';
    }
}
$pdf->Cell(0, 7, $waktu_str, 0, 1, 'L');
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->Cell(50, 7, "Tempat / Lokasi", 0, 0, 'L');
$pdf->Cell(5, 7, ":", 0, 0, 'C');
$pdf->MultiCell(0, 7, $k['lokasi'] ?: '-', 0, 'L');
$pdf->Ln(4);

// IV. HASIL KEGIATAN
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'IV. HASIL KEGIATAN', 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);

if ($k['tipe_kegiatan'] === 'monev') {
    // Professional Monev Layout
    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'A. TEMUAN DI LAPANGAN', 0, 1);
    $pdf->SetFont('Arial', '', 11);
    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->MultiCell(0, 6, $k['temuan'] ?: '-', 0, 'L');
    $pdf->Ln(2);

    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'B. SARAN DAN REKOMENDASI', 0, 1);
    $pdf->SetFont('Arial', '', 11);
    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->MultiCell(0, 6, $k['saran_rekomendasi'] ?: '-', 0, 'L');
    $pdf->Ln(2);

    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(35, 7, 'C. CAPAIAN (%)', 0, 0);
    $pdf->Cell(5, 7, ':', 0, 0);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, $k['capaian'] . '% Terlaksana', 0, 1);
    $pdf->Ln(2);

    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'D. NARASI KEGIATAN', 0, 1);
    $pdf->SetFont('Arial', '', 11);
    $pdf->SetX($pdf->GetLMargin() + 5);
    $pdf->MultiCell(0, 6, $k['deskripsi'], 0, 'J');
} else {
    $pdf->SetX($pdf->GetLMargin() + 10); // Adjusted indentation for non-monev
    $desc = $k['deskripsi'] ?: 'Kegiatan telah dilaksanakan dengan baik sesuai dengan rencana kerja yang telah ditetapkan.';
    $pdf->MultiCell(0, 7, $desc, 0, 'J');
}
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'V. PENUTUP', 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);
$pdf->SetX($pdf->GetLMargin() + 10);
$pdf->MultiCell(0, 7, "Demikian laporan hasil pelaksanaan tugas ini dibuat untuk dapat dipergunakan sebagaimana mestinya dan sebagai bahan evaluasi pimpinan lebih lanjut.", 0, 'J');
$pdf->Ln(5);

// VI. TIM PELAKSANA (NEW)
if (!empty($contributors)) {
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 8, 'VI. TIM PELAKSANA / KONTRIBUTOR', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 11);
    $pdf->SetX($pdf->GetLMargin() + 10);
    $tim_names = implode(', ', $contributors);
    $pdf->MultiCell(0, 7, "Personil yang terlibat dalam dokumentasi lapangan: " . $tim_names, 0, 'J');
    $pdf->Ln(5);
}

// 5. Documentation Layout (Standard 5.2 - Landscape)
if (!empty($fotos)) {
    // Switch to Landscape (Standard 2.2)
    $pdf->SetMargins(30, 40, 30); // T:4, L:3, R:3 (Landscape Standard 3.2)
    $pdf->AddPage('L');
    
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'LAMPIRAN DOKUMENTASI FOTO', 0, 1, 'C');
    $pdf->Ln(5);

    $grid_w = $pdf->GetPageWidth() - $pdf->GetLMargin() - $pdf->GetRMargin();
    $img_w = ($grid_w - 15) / 2; // 2 column grid
    $img_h = $img_w * 0.75; // 4:3 ratio
    
    $count = 0;
    foreach ($fotos as $idx => $f) {
        $img_path = 'uploads/foto/' . $f['file'];
        if (file_exists($img_path)) {
            // Check page overflow (Standard 7.2 - Max 4 per page)
            if ($count > 0 && $count % 4 == 0) {
                $pdf->AddPage('L');
                $pdf->SetY(85); // Adjust for header
            }

            // Calculate Grid Position
            $col = $count % 2;
            $row = floor(($count % 4) / 2);
            
            $x = $pdf->GetLMargin() + ($col * ($img_w + 10));
            $y = $pdf->GetY() + ($row * ($img_h + 20));

            $img_type = get_fpdf_image_type($img_path);

            if ($img_type) {
                $pdf->Image($img_path, $x, $y, $img_w, $img_h, $img_type);
                
                // Caption (Standard 7.3)
                $pdf->SetXY($x, $y + $img_h + 2);
                $pdf->SetFont('Arial', 'B', 10);
                $pdf->Cell($img_w, 5, 'Gambar ' . ($idx + 1) . '.', 0, 1, 'C');
                
                $pdf->SetX($x);
                $pdf->SetFont('Arial', '', 9);
                $contributor_text = 'Kontributor: ' . ($f['contributor'] ?: 'Sistem');
                if ($f['keterangan']) {
                    $contributor_text .= ' - "' . $f['keterangan'] . '"';
                }
                $pdf->MultiCell($img_w, 4, $contributor_text, 0, 'C');
                
                $count++;
            }
        }
    }
}

// 6. Signature (Standard 10)
if ($pdf->GetY() > ($pdf->GetPageHeight() - 80)) $pdf->AddPage($orient);

// Ensure margins for signature block
if ($orient === 'P') {
    $pdf->SetMargins(40, 30, 30);
} else {
    $pdf->SetMargins(30, 40, 30);
}

$pdf->SetY($pdf->GetPageHeight() - 70); // 7cm from bottom
$pdf->SetFont('Arial', '', 11);

// Signature on Right (Standard 10)
$right_w = 70;
$pdf->SetX($pdf->GetPageWidth() - $pdf->GetRMargin() - $right_w);
$pdf->Cell($right_w, 6, 'Besuk, ' . date('d', strtotime($k['tanggal'])) . ' ' . ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'][date('n', strtotime($k['tanggal']))] . ' ' . date('Y', strtotime($k['tanggal'])), 0, 1, 'L');
$pdf->SetX($pdf->GetPageWidth() - $pdf->GetRMargin() - $right_w);
$pdf->Cell($right_w, 6, 'Mengetahui,', 0, 1, 'L');
$pdf->SetX($pdf->GetPageWidth() - $pdf->GetRMargin() - $right_w);
$pdf->Cell($right_w, 6, $kop['jabatan_ttd'] ?? 'Camat Besuk', 0, 1, 'L');
$pdf->Ln(20);
$pdf->SetX($pdf->GetPageWidth() - $pdf->GetRMargin() - $right_w);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell($right_w, 6, strtoupper($kop['nama_camat']), 0, 1, 'L');
if (!empty($kop['golongan_ttd'])) {
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell($right_w, 6, $kop['golongan_ttd'], 0, 1, 'L');
}
$pdf->SetX($pdf->GetPageWidth() - $pdf->GetRMargin() - $right_w);
$pdf->SetFont('Arial', '', 11);
$pdf->Cell($right_w, 6, 'NIP. ' . $kop['nip_camat'], 0, 0, 'L');

$pdf->Output('I', 'Laporan_' . preg_replace('/[^a-zA-Z0-9]/', '_', $k['judul']) . '.pdf');
?>
